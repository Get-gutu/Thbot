async function sendMessage() {

  const message = document.getElementById("message").value;

  const res = await fetch("/send", {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify({ message })
  });

  const data = await res.json();

  document.getElementById("status").innerText =
    data.message || data.error;
}