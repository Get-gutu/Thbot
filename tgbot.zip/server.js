const express = require("express");
const TelegramBot = require("node-telegram-bot-api");
const path = require("path");

const app = express();

const TOKEN = "YOUR_BOT_TOKEN";
const CHAT_ID = "YOUR_CHAT_ID";

const bot = new TelegramBot(TOKEN, { polling: true });

app.use(express.static(path.join(__dirname, "public")));
app.use(express.json());

// Receive messages from website
app.post("/send", async (req, res) => {
  const { message } = req.body;

  try {
    await bot.sendMessage(CHAT_ID, message);

    res.json({
      success: true,
      message: "Message sent to Telegram bot"
    });
  } catch (error) {
    res.json({
      success: false,
      error: error.message
    });
  }
});

// Bot commands
bot.on("message", (msg) => {
  const chatId = msg.chat.id;

  if (msg.text === "/start") {
    bot.sendMessage(chatId, "Website bot connected");
  }
});

app.listen(3000, () => {
  console.log("Server running on port 3000");
});